package Assignment;

public class FirstTenNaturalNo {

	public static void main(String[] args) {

		// Using while loop

		int i = 1;

		while (i <= 10) {

			System.out.println("Natural Number " + i);

			i++;
		}

		// Using for Loop

		/*
		 * for (i =1; i<=10; i++) {
		 * 
		 * System.out.println("natural Number "+i); }
		 */

	}

}
