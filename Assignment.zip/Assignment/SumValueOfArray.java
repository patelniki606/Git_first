package Assignment;

public class SumValueOfArray {

	public static void main(String[] args) {

		int a[] = { 5, 8, 66, 77, 24, 36, 54, 78 };
		int sum = 0;

		for (int i = 0; i <= a.length - 1; i++)

		{

			sum = sum + a[i];

		}
		System.out.println("Sum of Array " + sum);

		// Enhanced for loop

		int z[] = { 5, 9, 7, 4, 3, 5, 9, 5 };
		int sum1 = 0;

		for (int value : z) { // value is 5 then 9 then 7

			sum1 = sum1 + value; // 0+5 then 5+9 nd so on
		}

		System.out.println("Sum of Array " + sum1);

	}

}
