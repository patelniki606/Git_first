package Assignment;

abstract class parents {

	public void message() {

		System.out.println("Hiiiiiiiiii Dear");
	}

}

class firstsubclass extends parents {

	public void message() {
		System.out.println("This is first subclass ");
	}
}

class secondsubclass extends parents {

	public void message() {
		System.out.println("This is second subclass ");
	}
}

public class AbstractMethod {

	public static void main(String[] args) {

		firstsubclass A = new firstsubclass();
		A.message();

		secondsubclass B = new secondsubclass();
		B.message();

	}

}
