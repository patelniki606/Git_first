package Assignment;

import java.rmi.AccessException;

public class TryBlock {

	public static void main(String[] args) {

		try {
			int A = 100 / 0;
		}

		catch (Exception e) {

			System.out.println("can't devide by Zero");
		}

		
		System.out.println("-------------------------------------------------");
		

		try {
		int [] Array = {1,3,6,9,7,5};
		
		System.out.println(Array[8]);
		}
		
		catch (Exception Z) {
			System.out.println(Z);
		}
		
		
		System.out.println("Possibe to get exception");
		
		
		
		
	}

}
