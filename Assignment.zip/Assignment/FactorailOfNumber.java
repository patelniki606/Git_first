package Assignment;

public class FactorailOfNumber {

	public static void main(String[] args) {

		// decrement method of I
		/*
		 * int num = 18;
		 * 
		 * long factorial = 1;
		 * 
		 * for (int i=num; i >= 1; i--) {
		 * 
		 * factorial = factorial * i;
		 * 
		 * }
		 * 
		 * System.out.println("Factorial of Number is " + factorial);
		 */

		// Increment method of N

		int number = 25;

		long output = 1;

		for (int N = 1; N <= number; N++) {

			output = output * N;

		}

		System.out.println("output of Number is " + output);
	}

}
