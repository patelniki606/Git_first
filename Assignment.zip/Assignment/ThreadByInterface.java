package Assignment;

public class ThreadByInterface implements Runnable {

	public void run() {
		System.out.println("thread is running...");
	}

	public static void main(String args[]) {
		ThreadByInterface m1 = new ThreadByInterface();
		Thread t1 = new Thread(m1);
		t1.start();
	}
}
