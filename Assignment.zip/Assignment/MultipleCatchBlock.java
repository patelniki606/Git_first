package Assignment;

public class MultipleCatchBlock {

	public static void main(String[] args) {

		try {
			String Array[] = new String[10];
			Array[10] = "Hello";

			System.out.println(Array[11]);
		}

		catch (ExceptionInInitializerError B) {
			System.out.println("Zaro error");

		}

		catch (ArrayStoreException C) {
			System.out.println("Array error");
		}

		catch (ArithmeticException D) {
			System.out.println("Arithmatic error");
		}

		catch (Exception E) {
			System.out.println("Exception");
		}
	}

}
