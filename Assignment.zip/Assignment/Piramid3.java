package Assignment;

public class Piramid3 {

	public static void main(String[] args) {

		  for (int i = 1; i <= 4; i++) {
	            // Print spaces before numbers
	            for (int j = 1; j <= 4 - i; j++) {
	                System.out.print("   ");
	            }
	            
	            // Print the numbers
	            for (int j = 1; j <= i; j++) {
	                System.out.print(i + "    ");
	            }
	            
	            System.out.println();
	        }
}
}