package Assignment;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number");
		int num = sc.nextInt();

		// 1. Using Algorithm

		int rev = 0;

		while (num != 0) {

			rev = rev * 10 + num % 10; // num % gives last value 
			num = num / 10; // num / eliminate last value
		}

		System.out.println("Reverese number is " + rev);

		// 2. Using StringBuffer class

		/*
		 * StringBuffer sb = new StringBuffer(String.valueOf(num)); // conver string value to num 
		 *  StringBuffer rev =sb.reverse();
		 * 
		 * System.out.println("Reverese number is " + rev);
		 */

		// 3. Using StringBuilder Class

		/*
		 * StringBuilder sbl = new StringBuilder(); 
		 * sbl.append(num);                                // append method will take number
		 *  StringBuilder rev = sbl.reverse();
		 * 
		 * System.out.println("Reverese number is " + rev);
		 */

	}

}
