package Assignment;

public class StringConcate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String S1 = "Hello";
		String S2 = "World";

		System.out.println(S1 + " " + S2);

		String A1 = " Its been long time since we met";
		String A2 = "HI , How are you?";
		String A3 = A2.concat(A1);

		System.out.println(A3);
	}

}
