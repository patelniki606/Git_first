package Assignment;

public class CompareTwoStrings {

	public static void main(String[] args) {

		String s1 = "Hello , Whats app";
		String s2 = "Dear , Hope you are doing well";
		String s3 = "Kevi is good source of Vitamin A";

		System.out.println(s1);
		System.out.println(s2);

		if (s1.compareTo(s2) > 0)
			System.out.println("S1 comes after S2");
		if (s1.compareTo(s2) < 0)
			System.out.println("S1 comes before S2");
		if (s1.compareTo(s2) == 0)
			System.out.println("S1 equals to S2");

		System.out.println("************************************************************");

		System.out.println(s1);
		System.out.println(s3);
		if (s1.compareTo(s3) > 0)
			System.out.println("S1 comes after S3");
		if (s1.compareTo(s3) < 0)
			System.out.println("S1 comes before S3");
		if (s1.compareTo(s3) == 0)
			System.out.println("S1 equals to S3");

		System.out.println("************************************************************");

		System.out.println(s2);
		System.out.println(s3);
		if (s2.compareTo(s3) > 0)
			System.out.println("S2 comes after S3");
		if (s2.compareTo(s3) < 0)
			System.out.println("S2 comes before S3");
		if (s2.compareTo(s3) == 0)
			System.out.println("S2 equals to S3");

	}

}
