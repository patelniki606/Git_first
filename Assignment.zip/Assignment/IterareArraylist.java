package Assignment;

import java.util.ArrayList;

public class IterareArraylist {

	public static void main(String[] args) {
		
		
		ArrayList<String> Car = new ArrayList<String>();
		Car.add("BMW");
		Car.add("Audi");
		Car.add("Furtuner");
		Car.add("Rolls Royals");
		
		System.out.println("Car Name is "+ Car);
		 
		for (int i=0;i<Car.size();i++ ) {
			System.out.println(Car.get(i));
			
		}

	}

}
