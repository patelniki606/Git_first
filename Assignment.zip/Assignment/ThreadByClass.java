package Assignment;

public class ThreadByClass extends Thread {

	public void run() {
		System.out.println("thread is running...");
	}

	public static void main(String args[]) {
		ThreadByClass t1 = new ThreadByClass();
		t1.start();
	}
}
