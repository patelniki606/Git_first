package Assignment;

public class IndexOfArray {

	public static void main(String[] args) {
		
		String [] Fruits = {"Apple" , "Orange" , "Kivi" , "Blueberry"};
		
		int index =0;
		
		for (int i = 1; i<Fruits.length; i++) {
			if(Fruits[i]== "Blueberry") {
				index = i;
			}
			
			System.out.println("Index of Blueberry is "+ index);
		}

		
		
		
	}

}
