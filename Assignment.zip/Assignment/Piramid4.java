package Assignment;


public class Piramid4 {
	
public static void Piramid(int n) {
    int rows = n * 2 - 1;

    for (int i = 1; i <= rows; i++) {
        int spaces = Math.abs(n - i);

        // Print leading spaces
        for (int j = 1; j <= spaces; j++) {
            System.out.print("  ");
        }

        int stars = rows - (2 * spaces);
        

        // Print stars
        for (int j = 1; j <= stars; j++) {
            System.out.print("* ");
        }

        System.out.println();
    }
}

public static void main(String[] args) {
    int n = 3;
    Piramid(n);
}
}
