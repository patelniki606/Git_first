package Assignment;

import java.util.Arrays;

public class SecondLargestElement {

	public static void main(String[] args) {
		
		// when value doesn't repeat
		
		int [] a = {77,55,45,62,11,84,22};
		Arrays.sort(a);
		
		System.out.println("Second Largest element "+ a[a.length-2]);
		

		
		// when value repeats
		
		
	}

}
