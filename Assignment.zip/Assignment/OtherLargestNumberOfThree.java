package Assignment;

import java.util.Scanner;

public class OtherLargestNumberOfThree {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the First Number");
		int a = sc.nextInt();

		System.out.println("Enter the Second Number");
		int b = sc.nextInt();

		System.out.println("Enter the Third Number");
		int c = sc.nextInt();

		int Largest1 = a > b ? a : b; // Large between a and b
		int Largest2 = c > Largest1 ? c : Largest1; // Large between Largest1 and c

		System.out.println(Largest2 + "is Largest number");

	}

}
