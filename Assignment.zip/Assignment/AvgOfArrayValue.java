package Assignment;

public class AvgOfArrayValue {

	public static void main(String[] args) {

		int a[] = { 5, 78, 56, 96, 55, 32, 82 };
		int sum = 0;

		for (int i = 0; i < a.length - 1; i++) {

			sum = sum + a[i] / a.length;
		}

		System.out.println("Average value of Array is " + sum);
	}

}
