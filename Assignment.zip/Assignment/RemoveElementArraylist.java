package Assignment;

import java.util.ArrayList;

public class RemoveElementArraylist {

	public static void main(String[] args) {
		
		
		ArrayList<String> Country = new ArrayList<String>();
		Country.add("India");
		Country.add("Canada");
		Country.add("USA");
		Country.add("Australia");
		Country.add("Dubai");
		
		System.out.println("Countries are "+ Country);
		Country.remove(3);
		System.out.println("Afrer removing 3rd array the Countries are "+ Country);
		

		
	}

}
