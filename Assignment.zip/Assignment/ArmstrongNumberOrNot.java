package Assignment;

import java.util.Scanner;

public class ArmstrongNumberOrNot {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number");

		int num = sc.nextInt();

		int cube = 0;
		int r; // Reminder
		int t;
		t = num;

		while (num > 0) {
			r = num % 10; // 153/%3 = 3
			t = num / 10; // 153/3 = 15 delete last degit
			cube = cube + (r * r * r); // 0+3*3*3 = 27

		}

		if (num == cube) {
			System.out.println("This is Armstrong Number");
		}

		else {
			System.out.println("This is not Armstrong number");
		}

	}

}
