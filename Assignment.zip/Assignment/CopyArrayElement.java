package Assignment;

public class CopyArrayElement {

	public static void main(String[] args) {

		int[] oldArray = { 11, 22, 33, 44, 55, 66, 77 }; // create old array
		int[] newArray = new int[oldArray.length]; // create new array

		for (int i = 0; i < oldArray.length; i++) { // loop though old array and copy element into new array
			newArray[i] = oldArray[i];
		}

		for (int i = 0; i < oldArray.length; i++) { // loop through new array and print new array

			System.out.println(newArray[i]);
		}
	}

}
