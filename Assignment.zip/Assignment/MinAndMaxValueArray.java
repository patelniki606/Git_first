package Assignment;

public class MinAndMaxValueArray {

	public static void main(String[] args) {

		int a[] = { 500, 600, 800, 200, 400, 700, 1000 };

		int max = a[0];

		for (int i = 1; i < a.length; i++) {

			if (a[i] > max) {

				max = a[i];

			}

		}

		System.out.println("Maximun value " + max);

		int min = a[0];

		for (int i = 1; i < a.length; i++) {

			if (a[i] < min) {

				min = a[i];
			}
		}

		System.out.println("Minimum Value " + min);

	}

}
