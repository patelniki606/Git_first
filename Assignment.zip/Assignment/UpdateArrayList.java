package Assignment;

import java.util.ArrayList;

public class UpdateArrayList {

	public static void main(String[] args) {

		ArrayList<Integer> List = new ArrayList<Integer>();

		List.add(78);
		List.add(45);
		List.add(96);
		List.add(22);
		List.add(65);

		System.out.println("List before Update " + List);

		// update 96 with 88

		int N = List.indexOf(96);

		// set updatation

		List.set(N, 88);

		System.out.println("List after Upadate " + List);

	}

}
